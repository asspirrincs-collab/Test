import { Cow, CowStatus } from '../types';

const STORAGE_KEY = 'moomanager_cows_v1';
const FARM_NAME_KEY = 'moomanager_farm_name';
const DEFAULT_IMAGE_KEY = 'moomanager_default_image_custom';

// Base64 SVG Placeholder for "Default Cow" (Fallback)
export const FALLBACK_DEFAULT_IMAGE = `data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA1MTIgNTEyIiBzdHlsZT0iYmFja2dyb3VuZC1jb2xvcjogI2YzZjRZjYiPjxwYXRoIGZpbGw9IiMzNzQxNTEiIGQ9Ik0yNTYgNDhDMTQxLjEgNDggNDggMTQxLjEgNDggMjU2czkzLjEgMjA4IDIwOCAyMDggMjA4LTkzLjEgMjA4LTIwOFMzNzAuOSA0OCAyNTYgNDh6bTAgNDMyYy0xMjMuNyAwLTIyNC0xMDAuMy0yMjQtMjI0UzEzMi4zIDMyIDI1NiAzMnMyMjQgMTAwLjMgMjI0IDIyNC0xMDAuMyAyMjQtMjI0IDIyNHoiLz48cGF0aCBmaWxsPSIjMzc0MTUxIiBkPSJNMTc2IDE5MmgyNHY2NGgtMjR6bTEzNiAwaDI0djY0aC0yNHoiLz48cGF0aCBmaWxsPSIjMzc0MTUxIiBkPSJNMjU2IDM1MmMtNDQuMiAwLTgwLTI2LjktODAtNjBoMTYwYy0uMSAzMy4xLTM1LjggNjAtODAgNjB6Ii8+PC9zdmc+`;

const generateId = (): string => Math.random().toString(36).substr(2, 9);

const MOCK_DATA: Cow[] = [
  {
    id: '1',
    name: 'Зорька',
    tagNumber: 'RU-12345',
    birthDate: '2020-05-15',
    breed: 'Голштинская',
    status: CowStatus.ACTIVE,
    inseminationDate: '2023-11-20',
    weightHistory: [
      { date: '2023-01-10', weight: 450 },
      { date: '2023-06-15', weight: 520 },
      { date: '2023-12-01', weight: 580 },
    ],
    milkHistory: [
      { date: '2024-02-01', liters: 25 },
      { date: '2024-02-02', liters: 24.5 },
      { date: '2024-02-03', liters: 26 },
    ],
    notes: 'Спокойный характер, высокий удой.',
    photoUrl: 'https://picsum.photos/400/300?random=1'
  },
  {
    id: '2',
    name: 'Бурёнка',
    tagNumber: 'RU-67890',
    birthDate: '2021-08-10',
    breed: 'Симментальская',
    status: CowStatus.ACTIVE,
    weightHistory: [
      { date: '2023-02-01', weight: 300 },
      { date: '2023-08-01', weight: 410 },
    ],
    milkHistory: [],
    notes: 'Требует внимания к копытам.',
    photoUrl: undefined 
  }
];

// --- Default Image Logic ---
export const getGlobalDefaultImage = (): string => {
    return localStorage.getItem(DEFAULT_IMAGE_KEY) || FALLBACK_DEFAULT_IMAGE;
};

export const saveGlobalDefaultImage = (base64Image: string) => {
    localStorage.setItem(DEFAULT_IMAGE_KEY, base64Image);
};

export const resetGlobalDefaultImage = () => {
    localStorage.removeItem(DEFAULT_IMAGE_KEY);
};

// --- COW CRUD ---

export const getCows = (): Cow[] => {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : MOCK_DATA;
  } catch (e) {
    console.error("Error loading cows", e);
    return [];
  }
};

export const saveCows = (cows: Cow[]) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cows));
};

export const addCow = (cowData: Omit<Cow, 'id'>): Cow => {
  const newCow: Cow = { 
      ...cowData, 
      id: generateId(),
      photoUrl: cowData.photoUrl,
      milkHistory: cowData.milkHistory || []
  };
  const currentCows = getCows();
  const updatedCows = [newCow, ...currentCows];
  saveCows(updatedCows);
  return newCow;
};

export const updateCow = (updatedCow: Cow) => {
  const currentCows = getCows();
  const newCows = currentCows.map(c => c.id === updatedCow.id ? updatedCow : c);
  saveCows(newCows);
};

export const deleteCow = (id: string) => {
  const currentCows = getCows();
  const newCows = currentCows.filter(c => c.id !== id);
  saveCows(newCows);
};

// --- Farm Name Logic ---

export const getFarmName = (): string => {
    return localStorage.getItem(FARM_NAME_KEY) || 'Ферма "Заря"';
};

export const saveFarmName = (name: string) => {
    localStorage.setItem(FARM_NAME_KEY, name);
    window.dispatchEvent(new Event('farmNameChanged'));
};

// --- CSV Import/Export Logic ---

const escapeCSV = (str: string | undefined | null): string => {
    if (!str) return '';
    const stringValue = String(str);
    if (stringValue.includes(',') || stringValue.includes('"') || stringValue.includes('\n')) {
        return `"${stringValue.replace(/"/g, '""')}"`;
    }
    return stringValue;
};

export const exportCowsToCSV = (): string => {
    const cows = getCows();
    const headers = ['ID', 'Name', 'TagNumber', 'BirthDate', 'Breed', 'InseminationDate', 'Status', 'Notes', 'WeightHistoryJSON', 'MilkHistoryJSON', 'PhotoUrl'];
    
    const rows = cows.map(cow => [
        cow.id,
        cow.name,
        cow.tagNumber,
        cow.birthDate,
        cow.breed,
        cow.inseminationDate,
        cow.status,
        cow.notes,
        JSON.stringify(cow.weightHistory),
        JSON.stringify(cow.milkHistory),
        cow.photoUrl
    ].map(escapeCSV).join(','));

    return [headers.join(','), ...rows].join('\n');
};

export const importCowsFromCSV = async (csvText: string): Promise<{ success: number; errors: number }> => {
    try {
        const lines = csvText.split('\n').filter(line => line.trim() !== '');
        if (lines.length < 2) return { success: 0, errors: 0 };

        const parseLine = (text: string) => {
            const result = [];
            let current = '';
            let inQuotes = false;
            for (let i = 0; i < text.length; i++) {
                const char = text[i];
                if (char === '"') {
                    if (inQuotes && text[i + 1] === '"') {
                        current += '"';
                        i++; 
                    } else {
                        inQuotes = !inQuotes;
                    }
                } else if (char === ',' && !inQuotes) {
                    result.push(current);
                    current = '';
                } else {
                    current += char;
                }
            }
            result.push(current);
            return result;
        };

        const headers = parseLine(lines[0]).map(h => h.trim().toLowerCase());
        const existingCows = getCows();
        const cowMap = new Map(existingCows.map(c => [c.id, c]));
        
        let successCount = 0;
        let errorCount = 0;

        for (let i = 1; i < lines.length; i++) {
            try {
                const values = parseLine(lines[i]);
                if (values.length < 2) continue;

                const getData = (headerPart: string) => {
                    const index = headers.findIndex(h => h.includes(headerPart.toLowerCase()));
                    return index !== -1 ? values[index] : '';
                };

                const id = getData('id') || generateId();
                const name = getData('name');
                const birthDate = getData('birthdate');

                if (!name || !birthDate) {
                    errorCount++;
                    continue;
                }

                let weightHistory = [];
                try {
                    const rawWeight = getData('weighthistory');
                    if (rawWeight) weightHistory = JSON.parse(rawWeight);
                } catch (e) {
                    console.warn('Failed to parse weight history for row ' + i);
                }

                let milkHistory = [];
                try {
                    const rawMilk = getData('milkhistory');
                    if (rawMilk) milkHistory = JSON.parse(rawMilk);
                } catch (e) {
                    console.warn('Failed to parse milk history for row ' + i);
                }

                const cow: Cow = {
                    id: id,
                    name: name,
                    tagNumber: getData('tag') || '',
                    birthDate: birthDate,
                    breed: getData('breed') || '',
                    inseminationDate: getData('insemination') || undefined,
                    status: (getData('status') as CowStatus) || CowStatus.ACTIVE,
                    notes: getData('notes') || '',
                    weightHistory: weightHistory,
                    milkHistory: milkHistory,
                    photoUrl: getData('photo') || undefined
                };

                cowMap.set(cow.id, cow);
                successCount++;
            } catch (e) {
                console.error("Error parsing row", i, e);
                errorCount++;
            }
        }

        saveCows(Array.from(cowMap.values()));
        return { success: successCount, errors: errorCount };

    } catch (e) {
        console.error("Import failed", e);
        throw new Error("Неверный формат файла");
    }
};