import { GoogleGenAI } from "@google/genai";
import { Cow } from "../types";

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.warn("API Key not found");
    return null;
  }
  return new GoogleGenAI({ apiKey });
};

export const analyzeCowHealth = async (cow: Cow, query: string): Promise<string> => {
  const client = getClient();
  if (!client) return "Пожалуйста, настройте API ключ для использования AI ассистента.";

  const prompt = `
    Ты эксперт в животноводстве и ветеринарии.
    
    Вот данные о корове:
    Имя: ${cow.name}
    Порода: ${cow.breed}
    Дата рождения: ${cow.birthDate}
    Вес (история): ${JSON.stringify(cow.weightHistory)}
    Дата осеменения: ${cow.inseminationDate || 'Нет'}
    Заметки: ${cow.notes}

    Вопрос фермера: "${query}"

    Дай краткий, практичный совет на русском языке. Если есть подозрения на проблемы со здоровьем, посоветуй обратиться к ветеринару.
  `;

  try {
    const response = await client.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text || "Не удалось получить ответ.";
  } catch (error) {
    console.error("Gemini API error:", error);
    return "Произошла ошибка при обращении к AI сервису.";
  }
};