import React, { useRef, useState, useEffect } from 'react';
import { Download, Upload, Trash2, FileSpreadsheet, CheckCircle, AlertCircle, Save, Image as ImageIcon, RotateCcw, Share2 } from 'lucide-react';
import { exportCowsToCSV, importCowsFromCSV, saveCows, getFarmName, saveFarmName, saveGlobalDefaultImage, getGlobalDefaultImage, resetGlobalDefaultImage, FALLBACK_DEFAULT_IMAGE } from '../services/storage';

const Settings: React.FC = () => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);
  const [notification, setNotification] = useState<{type: 'success' | 'error', msg: string} | null>(null);
  const [farmNameInput, setFarmNameInput] = useState('');
  const [defaultImage, setDefaultImage] = useState(getGlobalDefaultImage());

  useEffect(() => {
    setFarmNameInput(getFarmName());
    setDefaultImage(getGlobalDefaultImage());
  }, []);

  const showNotification = (type: 'success' | 'error', msg: string) => {
    setNotification({ type, msg });
    setTimeout(() => setNotification(null), 3000);
  };

  const handleSaveFarmName = () => {
      saveFarmName(farmNameInput);
      showNotification('success', 'Название фермы обновлено');
  };

  const handleDefaultImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          const reader = new FileReader();
          reader.onloadend = () => {
              const result = reader.result as string;
              saveGlobalDefaultImage(result);
              setDefaultImage(result);
              showNotification('success', 'Фото по умолчанию обновлено');
          };
          reader.readAsDataURL(file);
      }
  };

  const handleResetDefaultImage = () => {
      resetGlobalDefaultImage();
      setDefaultImage(FALLBACK_DEFAULT_IMAGE);
      showNotification('success', 'Восстановлено стандартное фото');
  };

  const handleExport = () => {
    try {
      const csv = exportCowsToCSV();
      // Add BOM for Excel UTF-8 support
      const blob = new Blob(["\ufeff", csv], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `MooManager_Backup_${new Date().toISOString().split('T')[0]}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      showNotification('success', 'Файл успешно скачан');
    } catch (e) {
      showNotification('error', 'Ошибка экспорта данных');
    }
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const text = event.target?.result as string;
        const result = await importCowsFromCSV(text);
        showNotification('success', `Импортировано: ${result.success}, Ошибок: ${result.errors}`);
        if (fileInputRef.current) fileInputRef.current.value = '';
      } catch (err) {
        showNotification('error', 'Ошибка чтения файла CSV');
      }
    };
    reader.readAsText(file);
  };

  const handleReset = () => {
    if (window.confirm("ЭТО УДАЛИТ ВСЕ ДАННЫЕ! Вы уверены?")) {
        saveCows([]);
        showNotification('success', 'База данных очищена');
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
        try {
            await navigator.share({
                title: 'MooManager',
                text: 'Управление стадом КРС',
                url: window.location.href,
            });
        } catch (error) {
            console.log('Error sharing:', error);
        }
    } else {
        // Fallback: copy to clipboard
        navigator.clipboard.writeText(window.location.href);
        showNotification('success', 'Ссылка скопирована!');
    }
  };

  return (
    <div className="space-y-6 pb-20">
      <h2 className="text-xl font-bold text-slate-800">Настройки</h2>

      {notification && (
        <div className={`p-4 rounded-xl flex items-center gap-2 ${
            notification.type === 'success' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
        }`}>
            {notification.type === 'success' ? <CheckCircle size={20}/> : <AlertCircle size={20}/>}
            <span className="text-sm font-medium">{notification.msg}</span>
        </div>
      )}

      {/* General Settings */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-4 border-b border-slate-100">
            <h3 className="font-bold text-slate-700">Общие</h3>
        </div>
        <div className="p-4 flex gap-2">
            <div className="flex-1">
                <label className="block text-xs font-medium text-slate-500 mb-1">Название фермы</label>
                <input 
                    type="text"
                    value={farmNameInput}
                    onChange={(e) => setFarmNameInput(e.target.value)}
                    className="w-full border border-slate-200 rounded-lg p-2 text-sm focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
            </div>
            <button 
                onClick={handleSaveFarmName}
                className="mt-5 bg-slate-800 text-white px-4 rounded-lg hover:bg-slate-900"
            >
                <Save size={18} />
            </button>
        </div>
      </div>

       {/* Mobile Access Helper */}
       <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-2xl shadow-md text-white overflow-hidden">
        <div className="p-4 flex items-center justify-between">
            <div>
                <h3 className="font-bold text-lg">Открыть на телефоне</h3>
                <p className="text-indigo-100 text-xs mt-1 max-w-[200px]">
                    Отправьте ссылку на это приложение себе на устройство.
                </p>
            </div>
            <button 
                onClick={handleShare}
                className="bg-white/20 hover:bg-white/30 p-3 rounded-full backdrop-blur-sm transition-all"
            >
                <Share2 size={24} />
            </button>
        </div>
      </div>

      {/* Default Image Settings */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-4 border-b border-slate-100">
            <h3 className="font-bold text-slate-700 flex items-center gap-2">
                <ImageIcon size={20} className="text-blue-500"/>
                Картинка по умолчанию
            </h3>
            <p className="text-xs text-slate-400 mt-1">
                Это изображение будет использоваться для коров без фото.
            </p>
        </div>
        <div className="p-4 flex items-center gap-4">
            <div className="w-16 h-16 rounded-lg overflow-hidden bg-slate-100 border border-slate-200 shrink-0">
                <img src={defaultImage} alt="Default" className="w-full h-full object-cover"/>
            </div>
            <div className="flex-1 space-y-2">
                <input 
                    type="file" 
                    accept="image/*"
                    ref={imageInputRef}
                    onChange={handleDefaultImageUpload}
                    className="hidden"
                />
                <button 
                    onClick={() => imageInputRef.current?.click()}
                    className="w-full py-2 bg-blue-50 text-blue-700 rounded-lg text-xs font-medium hover:bg-blue-100"
                >
                    Загрузить своё фото
                </button>
                <button 
                    onClick={handleResetDefaultImage}
                    className="w-full py-2 text-slate-500 rounded-lg text-xs font-medium hover:bg-slate-50 flex items-center justify-center gap-1"
                >
                    <RotateCcw size={14} /> Сбросить
                </button>
            </div>
        </div>
      </div>

      {/* Import / Export */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-4 border-b border-slate-100">
            <h3 className="font-bold text-slate-700 flex items-center gap-2">
                <FileSpreadsheet className="text-emerald-600" size={20} />
                Экспорт / Импорт (CSV)
            </h3>
        </div>
        
        <div className="p-6 space-y-4">
            <button 
                onClick={handleExport}
                className="w-full flex items-center justify-center gap-2 bg-emerald-50 text-emerald-700 border border-emerald-200 p-4 rounded-xl font-medium hover:bg-emerald-100 transition-colors"
            >
                <Download size={20} />
                Скачать таблицу (.csv)
            </button>

            <div className="relative">
                <input 
                    type="file" 
                    accept=".csv"
                    ref={fileInputRef}
                    onChange={handleFileChange}
                    className="hidden"
                />
                <button 
                    onClick={handleImportClick}
                    className="w-full flex items-center justify-center gap-2 bg-slate-50 text-slate-700 border border-slate-200 p-4 rounded-xl font-medium hover:bg-slate-100 transition-colors"
                >
                    <Upload size={20} />
                    Загрузить таблицу (.csv)
                </button>
            </div>
        </div>
      </div>

      {/* Danger Zone */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-4 border-b border-slate-100">
            <h3 className="font-bold text-red-700 flex items-center gap-2">
                <AlertCircle size={20} />
                Опасная зона
            </h3>
        </div>
        <div className="p-6">
             <button 
                onClick={handleReset}
                className="w-full flex items-center justify-center gap-2 bg-red-50 text-red-600 border border-red-200 p-3 rounded-xl font-medium hover:bg-red-100 transition-colors text-sm"
            >
                <Trash2 size={18} />
                Удалить все данные
            </button>
        </div>
      </div>
      
      <div className="text-center mt-8 px-4">
           <p className="text-xs text-slate-400 mb-2 font-semibold">КАК УСТАНОВИТЬ (PWA):</p>
           <ol className="text-left text-xs text-slate-500 space-y-2 list-decimal list-inside bg-slate-100 p-3 rounded-xl">
               <li>Откройте эту страницу в <b>Chrome</b> (Android) или <b>Safari</b> (iOS).</li>
               <li><b>Android:</b> Нажмите меню (⋮) -> "Установить приложение".</li>
               <li><b>iOS:</b> Нажмите "Поделиться" -> "На экран Домой".</li>
           </ol>
      </div>
    </div>
  );
};

export default Settings;