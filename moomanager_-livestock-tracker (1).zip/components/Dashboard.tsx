import React, { useState, useEffect } from 'react';
import { Cow } from '../types';
import { getCows } from '../services/storage';
import CowCard from './CowCard';
import { Search, Filter } from 'lucide-react';

const Dashboard: React.FC = () => {
  const [cows, setCows] = useState<Cow[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterActive, setFilterActive] = useState(false);

  useEffect(() => {
    setCows(getCows());
  }, []);

  const filteredCows = cows.filter(cow => 
    cow.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    cow.tagNumber.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-4">
      {/* Stats Summary */}
      <div className="grid grid-cols-2 gap-3 mb-2">
        <div className="bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl p-4 text-white shadow-sm">
            <p className="text-emerald-100 text-xs font-medium mb-1">Всего голов</p>
            <p className="text-3xl font-bold">{cows.length}</p>
        </div>
        <div className="bg-white border border-slate-100 rounded-xl p-4 shadow-sm">
            <p className="text-slate-400 text-xs font-medium mb-1">Средний вес</p>
            <p className="text-3xl font-bold text-slate-700">
                {cows.length > 0 ? Math.round(cows.reduce((acc, c) => {
                    const lastWeight = c.weightHistory.length > 0 ? c.weightHistory[c.weightHistory.length - 1].weight : 0;
                    return acc + lastWeight;
                }, 0) / cows.length) : 0} <span className="text-sm font-normal text-slate-400">кг</span>
            </p>
        </div>
      </div>

      {/* Search Bar */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Поиск по имени или бирке..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-white border border-slate-200 rounded-xl pl-10 pr-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 shadow-sm"
          />
        </div>
        <button className="bg-white border border-slate-200 rounded-xl px-3 text-slate-500 shadow-sm">
           <Filter size={20} />
        </button>
      </div>

      {/* List */}
      <div className="space-y-3 pb-20">
        <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-wider ml-1">Стадо</h2>
        {filteredCows.length > 0 ? (
          filteredCows.map(cow => <CowCard key={cow.id} cow={cow} />)
        ) : (
          <div className="text-center py-10">
            <p className="text-slate-400 text-sm">Животные не найдены.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;