import React from 'react';
import { Cow } from '../types';
import { ChevronRight, Calendar, Scale, AlertTriangle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { getGlobalDefaultImage } from '../services/storage';

interface CowCardProps {
  cow: Cow;
}

const calculateAge = (birthDate: string): string => {
  const birth = new Date(birthDate);
  const now = new Date();
  let months = (now.getFullYear() - birth.getFullYear()) * 12;
  months -= birth.getMonth();
  months += now.getMonth();
  
  if (months < 12) return `${months} мес.`;
  const years = Math.floor(months / 12);
  const remainingMonths = months % 12;
  return `${years} г. ${remainingMonths > 0 ? `${remainingMonths} мес.` : ''}`;
};

const getCalvingAlert = (inseminationDate?: string): boolean => {
    if (!inseminationDate) return false;
    const GESTATION_DAYS = 283;
    const insDate = new Date(inseminationDate);
    const calvingDate = new Date(insDate.getTime() + (GESTATION_DAYS * 24 * 60 * 60 * 1000));
    const now = new Date();
    
    // Difference in milliseconds
    const diffTime = calvingDate.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    // Alert if calving is within 3 weeks (21 days) and hasn't passed more than a week ago
    return diffDays <= 21 && diffDays > -7; 
};

const CowCard: React.FC<CowCardProps> = ({ cow }) => {
  const lastWeight = cow.weightHistory.length > 0 
    ? cow.weightHistory[cow.weightHistory.length - 1].weight 
    : '---';

  const hasCalvingAlert = getCalvingAlert(cow.inseminationDate);
  const defaultImg = getGlobalDefaultImage();

  return (
    <Link to={`/cow/${cow.id}`} className="block">
      <div className={`bg-white rounded-xl shadow-sm border overflow-hidden hover:shadow-md transition-shadow active:scale-[0.98] duration-150 relative ${hasCalvingAlert ? 'border-amber-400 ring-1 ring-amber-400' : 'border-slate-100'}`}>
        
        {hasCalvingAlert && (
             <div className="absolute top-0 right-0 bg-amber-500 text-white text-[10px] font-bold px-2 py-1 rounded-bl-lg z-10 flex items-center gap-1">
                 <AlertTriangle size={10} />
                 Скоро отёл
             </div>
        )}

        <div className="flex p-3 gap-4">
          <div className="w-20 h-20 bg-slate-200 rounded-lg flex-shrink-0 overflow-hidden">
             <img 
                src={cow.photoUrl || defaultImg} 
                alt={cow.name} 
                className="w-full h-full object-cover"
                loading="lazy"
                onError={(e) => {
                    (e.target as HTMLImageElement).src = defaultImg;
                }}
             />
          </div>
          
          <div className="flex-1 flex flex-col justify-between">
            <div className="flex justify-between items-start">
              <div className="pt-1">
                <h3 className="text-lg font-bold text-slate-800 leading-none">{cow.name}</h3>
                <p className="text-xs text-slate-500 font-mono mt-1">{cow.tagNumber}</p>
              </div>
              {!hasCalvingAlert && (
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${
                    cow.status === 'Активна' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'
                }`}>
                    {cow.status}
                </span>
              )}
            </div>

            <div className="flex items-center gap-4 mt-2 text-sm text-slate-600">
               <div className="flex items-center gap-1">
                 <Calendar size={14} className="text-slate-400"/>
                 <span>{calculateAge(cow.birthDate)}</span>
               </div>
               <div className="flex items-center gap-1">
                 <Scale size={14} className="text-slate-400"/>
                 <span>{lastWeight} кг</span>
               </div>
            </div>
          </div>
          
          <div className="flex items-center text-slate-300">
            <ChevronRight size={20} />
          </div>
        </div>
      </div>
    </Link>
  );
};

export default CowCard;