import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { addCow, getGlobalDefaultImage } from '../services/storage';
import { CowStatus } from '../types';
import { Save, Camera, X } from 'lucide-react';

const AddCow: React.FC = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: '',
    tagNumber: '',
    birthDate: '',
    breed: '',
    weight: '',
    notes: '',
  });
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.birthDate) {
        alert("Заполните обязательные поля");
        return;
    }

    addCow({
      name: formData.name,
      tagNumber: formData.tagNumber,
      birthDate: formData.birthDate,
      breed: formData.breed,
      status: CowStatus.ACTIVE,
      weightHistory: formData.weight ? [{
          date: new Date().toISOString().split('T')[0],
          weight: parseFloat(formData.weight)
      }] : [],
      milkHistory: [],
      notes: formData.notes,
      photoUrl: photoPreview || undefined 
    });

    navigate('/');
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removePhoto = () => {
    setPhotoPreview(null);
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 pb-20">
      <h2 className="text-xl font-bold text-slate-800 mb-6">Новое животное</h2>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="flex justify-center mb-6">
            <div className="relative w-full h-48 rounded-xl overflow-hidden border border-slate-200">
                <img 
                    src={photoPreview || getGlobalDefaultImage()} 
                    alt="Preview" 
                    className="w-full h-full object-cover" 
                />
                
                {photoPreview ? (
                    <button 
                        type="button" 
                        onClick={removePhoto}
                        className="absolute top-2 right-2 bg-black/50 text-white p-1 rounded-full hover:bg-black/70"
                    >
                        <X size={20} />
                    </button>
                ) : (
                    <label className="absolute inset-0 bg-black/20 flex flex-col items-center justify-center text-white cursor-pointer hover:bg-black/30 transition-colors">
                        <Camera size={32} className="mb-2" />
                        <span className="text-xs font-medium">Загрузить фото</span>
                        <input 
                            type="file" 
                            accept="image/*" 
                            capture="environment"
                            onChange={handlePhotoUpload}
                            className="hidden" 
                        />
                    </label>
                )}
            </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Кличка *</label>
          <input
            name="name"
            required
            value={formData.name}
            onChange={handleChange}
            placeholder="Например: Зорька"
            className="w-full border border-slate-200 rounded-lg p-3 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Бирка №</label>
              <input
                name="tagNumber"
                value={formData.tagNumber}
                onChange={handleChange}
                placeholder="RU-..."
                className="w-full border border-slate-200 rounded-lg p-3 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Порода</label>
              <input
                name="breed"
                value={formData.breed}
                onChange={handleChange}
                placeholder="Голштинская"
                className="w-full border border-slate-200 rounded-lg p-3 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Дата рождения *</label>
              <input
                type="date"
                name="birthDate"
                required
                value={formData.birthDate}
                onChange={handleChange}
                className="w-full border border-slate-200 rounded-lg p-3 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Текущий вес (кг)</label>
              <input
                type="number"
                name="weight"
                value={formData.weight}
                onChange={handleChange}
                placeholder="0"
                className="w-full border border-slate-200 rounded-lg p-3 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
            </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Заметки</label>
          <textarea
            name="notes"
            rows={3}
            value={formData.notes}
            onChange={handleChange}
            placeholder="Особенности, приметы..."
            className="w-full border border-slate-200 rounded-lg p-3 text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-none resize-none"
          />
        </div>

        <button 
          type="submit" 
          className="w-full bg-emerald-600 text-white font-bold py-3.5 rounded-xl hover:bg-emerald-700 transition-colors flex items-center justify-center gap-2 mt-4 shadow-lg shadow-emerald-200"
        >
          <Save size={20} />
          Сохранить карточку
        </button>
      </form>
    </div>
  );
};

export default AddCow;