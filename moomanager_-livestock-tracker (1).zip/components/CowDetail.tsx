import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Cow, CowStatus, WeightRecord, ChatMessage, MilkRecord } from '../types';
import { getCows, updateCow, deleteCow, getGlobalDefaultImage } from '../services/storage';
import { analyzeCowHealth } from '../services/geminiService';
import { 
  ArrowLeft, 
  Trash2, 
  Scale, 
  Syringe, 
  Plus, 
  Bot,
  Send,
  Baby,
  Pencil,
  Droplet,
  Activity,
  FileText
} from 'lucide-react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';

const CowDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [cow, setCow] = useState<Cow | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'info' | 'milk'>('info');
  
  // Modals
  const [showWeightModal, setShowWeightModal] = useState(false);
  const [showMilkModal, setShowMilkModal] = useState(false);
  const [showInseminationModal, setShowInseminationModal] = useState(false);
  const [showEditProfileModal, setShowEditProfileModal] = useState(false);
  
  // Form States
  const [newWeight, setNewWeight] = useState('');
  const [weightDate, setWeightDate] = useState(new Date().toISOString().split('T')[0]);
  
  const [newMilk, setNewMilk] = useState('');
  const [milkDate, setMilkDate] = useState(new Date().toISOString().split('T')[0]);

  const [inseminationDateInput, setInseminationDateInput] = useState('');

  // Edit Profile State
  const [editForm, setEditForm] = useState({ name: '', tagNumber: '', breed: '', birthDate: '' });

  // AI Chat State
  const [chatInput, setChatInput] = useState('');
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [isAiThinking, setIsAiThinking] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (id) {
      const allCows = getCows();
      const found = allCows.find(c => c.id === id);
      if (found) {
        setCow(found);
        setInseminationDateInput(found.inseminationDate || '');
        setEditForm({
            name: found.name,
            tagNumber: found.tagNumber,
            breed: found.breed,
            birthDate: found.birthDate
        });
      } else {
        navigate('/');
      }
      setLoading(false);
    }
  }, [id, navigate]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatHistory]);

  const handleDelete = () => {
    if (window.confirm('Вы уверены, что хотите удалить запись об этом животном?')) {
      if (cow) deleteCow(cow.id);
      navigate('/');
    }
  };

  const handleEditProfile = () => {
      if (!cow) return;
      const updatedCow = { ...cow, ...editForm };
      updateCow(updatedCow);
      setCow(updatedCow);
      setShowEditProfileModal(false);
  };

  const handleAddWeight = () => {
    if (!cow || !newWeight) return;
    const updatedCow = { ...cow };
    const newRecord: WeightRecord = {
      date: weightDate,
      weight: parseFloat(newWeight)
    };
    updatedCow.weightHistory = [...updatedCow.weightHistory, newRecord].sort((a, b) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );
    updateCow(updatedCow);
    setCow(updatedCow);
    setShowWeightModal(false);
    setNewWeight('');
  };

  const handleAddMilk = () => {
    if (!cow || !newMilk) return;
    const updatedCow = { ...cow };
    const newRecord: MilkRecord = {
      date: milkDate,
      liters: parseFloat(newMilk)
    };
    // Initialize if undefined (for old records)
    if (!updatedCow.milkHistory) updatedCow.milkHistory = [];
    
    updatedCow.milkHistory = [...updatedCow.milkHistory, newRecord].sort((a, b) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );
    updateCow(updatedCow);
    setCow(updatedCow);
    setShowMilkModal(false);
    setNewMilk('');
  };

  const handleUpdateInsemination = () => {
    if(!cow) return;
    const updatedCow = { ...cow, inseminationDate: inseminationDateInput || undefined };
    updateCow(updatedCow);
    setCow(updatedCow);
    setShowInseminationModal(false);
  };

  const handleAiAsk = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || !cow) return;

    const userMsg: ChatMessage = { role: 'user', text: chatInput };
    setChatHistory(prev => [...prev, userMsg]);
    setChatInput('');
    setIsAiThinking(true);

    const response = await analyzeCowHealth(cow, userMsg.text);
    
    setChatHistory(prev => [...prev, { role: 'model', text: response }]);
    setIsAiThinking(false);
  };

  const weightData = useMemo(() => {
    if (!cow) return [];
    return cow.weightHistory.map(w => ({
      date: new Date(w.date).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' }),
      weight: w.weight,
      rawDate: w.date
    }));
  }, [cow]);

  const milkData = useMemo(() => {
      if (!cow || !cow.milkHistory) return [];
      return cow.milkHistory.map(m => ({
          date: new Date(m.date).toLocaleDateString('ru-RU', { day: 'numeric', month: 'short' }),
          liters: m.liters
      }));
  }, [cow]);

  const predictedCalvingDate = useMemo(() => {
      if (!cow?.inseminationDate) return null;
      const date = new Date(cow.inseminationDate);
      date.setDate(date.getDate() + 283); 
      return date;
  }, [cow?.inseminationDate]);

  const getDaysUntilCalving = () => {
      if (!predictedCalvingDate) return null;
      const diff = predictedCalvingDate.getTime() - new Date().getTime();
      return Math.ceil(diff / (1000 * 60 * 60 * 24));
  };

  const daysUntilCalving = getDaysUntilCalving();
  const isUrgentOtel = daysUntilCalving !== null && daysUntilCalving <= 21 && daysUntilCalving >= -7;

  if (loading || !cow) return <div className="p-8 text-center text-slate-500">Загрузка...</div>;

  return (
    <div className="pb-20">
      {/* Top Nav */}
      <div className="flex items-center justify-between mb-4">
        <button onClick={() => navigate('/')} className="p-2 -ml-2 text-slate-600 hover:bg-slate-100 rounded-full">
          <ArrowLeft size={24} />
        </button>
        <div className="flex bg-slate-200 p-1 rounded-xl">
            <button 
                onClick={() => setActiveTab('info')}
                className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${activeTab === 'info' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-500'}`}
            >
                Инфо
            </button>
            <button 
                onClick={() => setActiveTab('milk')}
                className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${activeTab === 'milk' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-500'}`}
            >
                Молоко
            </button>
        </div>
        <button onClick={handleDelete} className="p-2 text-red-500 hover:bg-red-50 rounded-full">
          <Trash2 size={20} />
        </button>
      </div>

      {activeTab === 'info' ? (
        <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
            {/* Main Info Card */}
            <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden relative group">
                <button 
                    onClick={() => setShowEditProfileModal(true)}
                    className="absolute top-2 right-2 bg-white/80 p-2 rounded-full shadow-sm z-10 hover:bg-white"
                >
                    <Pencil size={16} className="text-slate-600" />
                </button>
                <img 
                    src={cow.photoUrl || getGlobalDefaultImage()} 
                    alt={cow.name} 
                    className="w-full h-48 object-cover" 
                    onError={(e) => { (e.target as HTMLImageElement).src = getGlobalDefaultImage(); }}
                />
                <div className="p-4 space-y-4">
                <div className="flex justify-between items-center">
                    <div>
                        <h2 className="text-2xl font-bold text-slate-800 leading-none mb-1">{cow.name}</h2>
                        <p className="text-sm text-slate-500">{cow.breed}</p>
                    </div>
                    <span className="px-3 py-1 bg-emerald-100 text-emerald-800 text-xs font-bold rounded-full">
                        {cow.status}
                    </span>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 bg-slate-50 rounded-xl">
                        <p className="text-xs text-slate-400 mb-1">Бирка №</p>
                        <p className="font-semibold text-slate-700">{cow.tagNumber}</p>
                    </div>
                    <div className="p-3 bg-slate-50 rounded-xl">
                        <p className="text-xs text-slate-400 mb-1">Возраст</p>
                        <p className="font-semibold text-slate-700">
                            {new Date().getFullYear() - new Date(cow.birthDate).getFullYear()} лет
                        </p>
                    </div>
                </div>
                
                {/* Reproduction Section */}
                <div className={`rounded-xl border ${isUrgentOtel ? 'bg-amber-50 border-amber-200' : 'bg-blue-50 border-blue-100'} p-3`}>
                    <div className="flex items-center justify-between mb-2">
                        <h4 className={`text-xs font-bold uppercase ${isUrgentOtel ? 'text-amber-700' : 'text-blue-700'}`}>Репродукция</h4>
                        <button onClick={() => setShowInseminationModal(true)} className="p-1.5 bg-white rounded-full shadow-sm hover:bg-slate-100">
                            <Pencil size={14} className="text-slate-500" />
                        </button>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <p className="text-xs opacity-70 mb-1 flex items-center gap-1">
                                <Syringe size={12} /> Осеменение
                            </p>
                            <p className="font-semibold text-sm">
                                {cow.inseminationDate ? new Date(cow.inseminationDate).toLocaleDateString('ru-RU') : '---'}
                            </p>
                        </div>
                        <div>
                            <p className="text-xs opacity-70 mb-1 flex items-center gap-1">
                                <Baby size={12} /> Предп. отел
                            </p>
                            <p className="font-semibold text-sm">
                                {predictedCalvingDate ? predictedCalvingDate.toLocaleDateString('ru-RU') : '---'}
                            </p>
                            {daysUntilCalving !== null && (
                                <p className={`text-[10px] mt-1 font-bold ${daysUntilCalving < 0 ? 'text-red-500' : isUrgentOtel ? 'text-amber-600' : 'text-slate-500'}`}>
                                    {daysUntilCalving < 0 ? `Прошло ${Math.abs(daysUntilCalving)} дн.` : `Через ${daysUntilCalving} дн.`}
                                </p>
                            )}
                        </div>
                    </div>
                </div>

                <div>
                    <h4 className="text-sm font-semibold text-slate-700 mb-1 flex items-center gap-1"><FileText size={14}/> Заметки</h4>
                    <p className="text-sm text-slate-500 bg-slate-50 p-3 rounded-lg italic border border-slate-100">
                        {cow.notes || "Нет заметок"}
                    </p>
                </div>
                </div>
            </div>

            {/* Weight Chart Section */}
            <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-4">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-slate-800 flex items-center gap-2">
                        <Scale size={20} className="text-emerald-600"/>
                        Вес
                    </h3>
                    <button 
                        onClick={() => setShowWeightModal(true)}
                        className="flex items-center gap-1 text-xs bg-emerald-600 text-white px-3 py-1.5 rounded-full shadow-sm active:bg-emerald-700"
                    >
                        <Plus size={14} /> Запись
                    </button>
                </div>
                
                <div className="h-48 w-full">
                    {weightData.length > 0 ? (
                        <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={weightData}>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                                <XAxis dataKey="date" tick={{fontSize: 10}} stroke="#94a3b8" />
                                <YAxis tick={{fontSize: 10}} stroke="#94a3b8" domain={['auto', 'auto']} />
                                <Tooltip 
                                    contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                                />
                                <Line 
                                    type="monotone" 
                                    dataKey="weight" 
                                    stroke="#059669" 
                                    strokeWidth={3}
                                    dot={{ fill: '#059669', strokeWidth: 2 }}
                                    activeDot={{ r: 6 }}
                                />
                            </LineChart>
                        </ResponsiveContainer>
                    ) : (
                        <div className="h-full flex items-center justify-center text-slate-400 text-sm bg-slate-50 rounded-xl">
                            Нет данных о весе
                        </div>
                    )}
                </div>
            </div>

            {/* AI Assistant Section */}
            <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-2xl shadow-sm border border-indigo-100 p-4">
                <div className="flex items-center gap-2 mb-4">
                    <div className="bg-indigo-600 p-2 rounded-lg text-white">
                        <Bot size={20} />
                    </div>
                    <div>
                        <h3 className="font-bold text-indigo-900">AI Вет-Ассистент</h3>
                        <p className="text-xs text-indigo-500">Анализ здоровья</p>
                    </div>
                </div>

                <div className="bg-white/60 backdrop-blur-sm rounded-xl p-3 h-48 overflow-y-auto mb-3 text-sm space-y-3 border border-indigo-50">
                    {chatHistory.length === 0 && (
                        <p className="text-center text-slate-400 mt-4 text-xs">
                            Спросите что-нибудь, например: <br/> "Нормальный ли вес для её возраста?"
                        </p>
                    )}
                    {chatHistory.map((msg, idx) => (
                        <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-[85%] p-2 rounded-lg ${
                                msg.role === 'user' 
                                ? 'bg-indigo-600 text-white rounded-br-none' 
                                : 'bg-white border border-slate-100 text-slate-700 rounded-bl-none shadow-sm'
                            }`}>
                                {msg.text}
                            </div>
                        </div>
                    ))}
                    {isAiThinking && (
                        <div className="flex justify-start">
                            <div className="bg-white px-3 py-2 rounded-lg rounded-bl-none text-xs text-slate-400 animate-pulse">
                                Анализирую данные...
                            </div>
                        </div>
                    )}
                    <div ref={messagesEndRef} />
                </div>

                <form onSubmit={handleAiAsk} className="flex gap-2">
                    <input 
                        type="text" 
                        value={chatInput}
                        onChange={(e) => setChatInput(e.target.value)}
                        placeholder="Вопрос ветеринару..."
                        className="flex-1 text-sm rounded-lg border-indigo-100 border focus:outline-none focus:ring-2 focus:ring-indigo-500 px-3 py-2"
                    />
                    <button 
                        type="submit" 
                        disabled={isAiThinking || !chatInput.trim()}
                        className="bg-indigo-600 text-white p-2 rounded-lg disabled:opacity-50 hover:bg-indigo-700"
                    >
                        <Send size={18} />
                    </button>
                </form>
            </div>
        </div>
      ) : (
        <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
             {/* Milk Chart Section */}
             <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-4">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-slate-800 flex items-center gap-2">
                        <Droplet size={20} className="text-blue-500"/>
                        График удоя
                    </h3>
                    <button 
                        onClick={() => setShowMilkModal(true)}
                        className="flex items-center gap-1 text-xs bg-blue-500 text-white px-3 py-1.5 rounded-full shadow-sm active:bg-blue-600"
                    >
                        <Plus size={14} /> Добавить
                    </button>
                </div>
                
                <div className="h-64 w-full">
                    {milkData.length > 0 ? (
                        <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={milkData}>
                                <defs>
                                    <linearGradient id="colorMilk" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.1}/>
                                        <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                                    </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                                <XAxis dataKey="date" tick={{fontSize: 10}} stroke="#94a3b8" />
                                <YAxis tick={{fontSize: 10}} stroke="#94a3b8" />
                                <Tooltip 
                                    contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                                />
                                <Area 
                                    type="monotone" 
                                    dataKey="liters" 
                                    stroke="#3b82f6" 
                                    fillOpacity={1} 
                                    fill="url(#colorMilk)" 
                                />
                            </AreaChart>
                        </ResponsiveContainer>
                    ) : (
                        <div className="h-full flex flex-col items-center justify-center text-slate-400 text-sm bg-slate-50 rounded-xl">
                            <Droplet size={32} className="mb-2 opacity-50"/>
                            <p>Нет записей об удое</p>
                        </div>
                    )}
                </div>
            </div>

            {/* Milk History List */}
            <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
                <div className="p-4 border-b border-slate-100 bg-slate-50">
                    <h3 className="font-bold text-slate-700 text-sm">История записей</h3>
                </div>
                <div className="divide-y divide-slate-100 max-h-80 overflow-y-auto">
                    {milkData.length > 0 ? (
                        [...milkData].reverse().map((record, i) => (
                            <div key={i} className="p-4 flex justify-between items-center">
                                <span className="text-sm text-slate-500">{record.date}</span>
                                <span className="text-sm font-bold text-slate-800">{record.liters} л.</span>
                            </div>
                        ))
                    ) : (
                        <div className="p-6 text-center text-xs text-slate-400">
                            История пуста
                        </div>
                    )}
                </div>
            </div>
        </div>
      )}

      {/* --- MODALS --- */}

      {/* Edit Profile Modal */}
      {showEditProfileModal && (
          <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
              <div className="bg-white rounded-2xl w-full max-w-sm p-6">
                  <h3 className="text-lg font-bold mb-4">Редактировать профиль</h3>
                  <div className="space-y-3">
                      <div>
                          <label className="text-xs font-medium text-slate-500">Кличка</label>
                          <input 
                             value={editForm.name} 
                             onChange={e => setEditForm({...editForm, name: e.target.value})}
                             className="w-full border border-slate-300 rounded-lg p-2"
                          />
                      </div>
                      <div>
                          <label className="text-xs font-medium text-slate-500">Бирка</label>
                          <input 
                             value={editForm.tagNumber} 
                             onChange={e => setEditForm({...editForm, tagNumber: e.target.value})}
                             className="w-full border border-slate-300 rounded-lg p-2"
                          />
                      </div>
                      <div>
                          <label className="text-xs font-medium text-slate-500">Порода</label>
                          <input 
                             value={editForm.breed} 
                             onChange={e => setEditForm({...editForm, breed: e.target.value})}
                             className="w-full border border-slate-300 rounded-lg p-2"
                          />
                      </div>
                      <div>
                          <label className="text-xs font-medium text-slate-500">Дата рождения</label>
                          <input 
                             type="date"
                             value={editForm.birthDate} 
                             onChange={e => setEditForm({...editForm, birthDate: e.target.value})}
                             className="w-full border border-slate-300 rounded-lg p-2"
                          />
                      </div>
                  </div>
                  <div className="flex gap-3 mt-6">
                    <button onClick={() => setShowEditProfileModal(false)} className="flex-1 py-2 text-slate-600 font-medium hover:bg-slate-50 rounded-lg">Отмена</button>
                    <button onClick={handleEditProfile} className="flex-1 py-2 bg-slate-800 text-white rounded-lg font-medium">Сохранить</button>
                  </div>
              </div>
          </div>
      )}

      {/* Add Weight Modal Overlay */}
      {showWeightModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl w-full max-w-sm p-6">
                <h3 className="text-lg font-bold mb-4">Взвешивание</h3>
                <div className="space-y-3">
                    <div>
                        <label className="block text-xs font-medium text-slate-500 mb-1">Дата</label>
                        <input 
                            type="date" 
                            value={weightDate}
                            onChange={(e) => setWeightDate(e.target.value)}
                            className="w-full border border-slate-300 rounded-lg p-2"
                        />
                    </div>
                    <div>
                        <label className="block text-xs font-medium text-slate-500 mb-1">Вес (кг)</label>
                        <input 
                            type="number" 
                            value={newWeight}
                            onChange={(e) => setNewWeight(e.target.value)}
                            placeholder="0.00"
                            className="w-full border border-slate-300 rounded-lg p-2"
                        />
                    </div>
                </div>
                <div className="flex gap-3 mt-6">
                    <button 
                        onClick={() => setShowWeightModal(false)}
                        className="flex-1 py-2 text-slate-600 font-medium hover:bg-slate-50 rounded-lg"
                    >
                        Отмена
                    </button>
                    <button 
                        onClick={handleAddWeight}
                        className="flex-1 py-2 bg-emerald-600 text-white rounded-lg font-medium hover:bg-emerald-700"
                    >
                        Сохранить
                    </button>
                </div>
            </div>
        </div>
      )}

      {/* Add Milk Modal Overlay */}
      {showMilkModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl w-full max-w-sm p-6">
                <h3 className="text-lg font-bold mb-4">Запись удоя</h3>
                <div className="space-y-3">
                    <div>
                        <label className="block text-xs font-medium text-slate-500 mb-1">Дата</label>
                        <input 
                            type="date" 
                            value={milkDate}
                            onChange={(e) => setMilkDate(e.target.value)}
                            className="w-full border border-slate-300 rounded-lg p-2"
                        />
                    </div>
                    <div>
                        <label className="block text-xs font-medium text-slate-500 mb-1">Литры</label>
                        <input 
                            type="number" 
                            value={newMilk}
                            onChange={(e) => setNewMilk(e.target.value)}
                            placeholder="0.00"
                            className="w-full border border-slate-300 rounded-lg p-2"
                        />
                    </div>
                </div>
                <div className="flex gap-3 mt-6">
                    <button 
                        onClick={() => setShowMilkModal(false)}
                        className="flex-1 py-2 text-slate-600 font-medium hover:bg-slate-50 rounded-lg"
                    >
                        Отмена
                    </button>
                    <button 
                        onClick={handleAddMilk}
                        className="flex-1 py-2 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600"
                    >
                        Сохранить
                    </button>
                </div>
            </div>
        </div>
      )}

      {/* Insemination Modal Overlay */}
      {showInseminationModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl w-full max-w-sm p-6">
                <h3 className="text-lg font-bold mb-4">Данные репродукции</h3>
                <div className="space-y-3">
                    <div>
                        <label className="block text-xs font-medium text-slate-500 mb-1">Дата осеменения</label>
                        <input 
                            type="date" 
                            value={inseminationDateInput}
                            onChange={(e) => setInseminationDateInput(e.target.value)}
                            className="w-full border border-slate-300 rounded-lg p-2"
                        />
                        <p className="text-[10px] text-slate-400 mt-1">
                            Оставьте пустым, если не осеменена.
                        </p>
                    </div>
                    {inseminationDateInput && (
                         <div className="bg-blue-50 p-3 rounded-lg">
                             <p className="text-xs text-blue-800">
                                 Предположительная дата отела: <br/>
                                 <span className="font-bold text-sm">
                                     {new Date(new Date(inseminationDateInput).getTime() + 283 * 24 * 60 * 60 * 1000).toLocaleDateString('ru-RU')}
                                 </span>
                             </p>
                         </div>
                    )}
                </div>
                <div className="flex gap-3 mt-6">
                    <button 
                        onClick={() => setShowInseminationModal(false)}
                        className="flex-1 py-2 text-slate-600 font-medium hover:bg-slate-50 rounded-lg"
                    >
                        Отмена
                    </button>
                    <button 
                        onClick={handleUpdateInsemination}
                        className="flex-1 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700"
                    >
                        Обновить
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default CowDetail;