import React, { useState, useEffect } from 'react';
import { Home, PlusCircle, Settings, Sprout } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { getFarmName } from '../services/storage';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const location = useLocation();
  const [farmName, setFarmName] = useState(getFarmName());

  const isActive = (path: string) => location.pathname === path;

  useEffect(() => {
    const handleFarmNameChange = () => {
        setFarmName(getFarmName());
    };
    window.addEventListener('farmNameChanged', handleFarmNameChange);
    return () => window.removeEventListener('farmNameChanged', handleFarmNameChange);
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-20 md:pb-0 font-sans">
      <header className="bg-emerald-600 text-white p-4 shadow-md sticky top-0 z-10">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-2">
                <Sprout size={24} />
                <h1 className="text-xl font-bold tracking-tight">MooManager</h1>
            </div>
            <div className="text-xs opacity-80">{farmName}</div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto p-4">
        {children}
      </main>

      {/* Mobile Bottom Nav */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 py-2 px-6 flex justify-between items-center z-50 md:hidden pb-safe">
        <Link to="/" className={`flex flex-col items-center gap-1 ${isActive('/') ? 'text-emerald-600' : 'text-slate-400'}`}>
          <Home size={24} />
          <span className="text-[10px] font-medium">Главная</span>
        </Link>
        <Link to="/add" className={`flex flex-col items-center gap-1 ${isActive('/add') ? 'text-emerald-600' : 'text-slate-400'}`}>
          <PlusCircle size={24} />
          <span className="text-[10px] font-medium">Добавить</span>
        </Link>
        <Link to="/settings" className={`flex flex-col items-center gap-1 ${isActive('/settings') ? 'text-emerald-600' : 'text-slate-400'}`}>
          <Settings size={24} />
          <span className="text-[10px] font-medium">Настройки</span>
        </Link>
      </nav>
      
      {/* Desktop Floating Action Button Replacement (if needed in future) */}
    </div>
  );
};

export default Layout;